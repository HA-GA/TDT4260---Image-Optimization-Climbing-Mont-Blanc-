#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <omp.h>
#include "ppm.h"

#define max(a,b) ((a) > (b) ? (a) : (b))
#define min(a,b) ((a) < (b) ? (a) : (b))

typedef struct {
    float red,green,blue;
} AccuratePixel;

typedef struct {
     int x, y;
     AccuratePixel *data;
} AccurateImage;

void convertToAccurateImage(PPMImage *image, AccurateImage *imageAccurate) {
    imageAccurate->x = image->x;
    imageAccurate->y = image->y;
    #pragma omp parallel for
    for (int i = 0; i < image->x * image->y; i++) {
        imageAccurate->data[i].red = (float) image->data[i].red;
        imageAccurate->data[i].green = (float) image->data[i].green;
        imageAccurate->data[i].blue = (float) image->data[i].blue;
    }
}


void transpose(AccuratePixel *src, AccuratePixel *dst, int width, int height) {
    #pragma omp parallel for simd
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            dst[x * height + y] = src[y * width + x];
        }
    }
}

void blurIteration(AccurateImage *imageOut, AccurateImage *imageIn, int kernelRadius, AccuratePixel *tempHorizontal, AccuratePixel *tempVertical) {
    int width = imageIn->x;
    int height = imageIn->y;

    #pragma omp parallel for simd
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            float sumRed = 0, sumGreen = 0, sumBlue = 0;
            int start = max(0, x - kernelRadius);
            int end = min(width - 1, x + kernelRadius);
            int count = end - start + 1;

            for (int i = start; i <= end; i++) {
                sumRed += imageIn->data[y * width + i].red;
                sumGreen += imageIn->data[y * width + i].green;
                sumBlue += imageIn->data[y * width + i].blue;
            }
            tempHorizontal[y * width + x].red = sumRed / count;
            tempHorizontal[y * width + x].green = sumGreen / count;
            tempHorizontal[y * width + x].blue = sumBlue / count;
        }
    }

    transpose(tempHorizontal, tempVertical, width, height);

    #pragma omp parallel for simd
    for (int y = 0; y < width; y++) {
        for (int x = 0; x < height; x++) {
            float sumRed = 0, sumGreen = 0, sumBlue = 0;
            int start = max(0, x - kernelRadius);
            int end = min(height - 1, x + kernelRadius);
            int count = end - start + 1;

            for (int i = start; i <= end; i++) {
                sumRed += tempVertical[y * height + i].red;
                sumGreen += tempVertical[y * height + i].green;
                sumBlue += tempVertical[y * height + i].blue;
            }
            tempHorizontal[y * height + x].red = sumRed / count;
            tempHorizontal[y * height + x].green = sumGreen / count;
            tempHorizontal[y * height + x].blue = sumBlue / count;
        }
    }

    transpose(tempHorizontal, imageOut->data, height, width);
}



static inline unsigned char processDifference(float large, float small) {
    float diff = large - small;
    diff = diff < -1.0 ? diff + 257.0 : diff;
    diff = diff < 0.0 ? 0.0 : (diff > 255.0 ? 255.0 : diff);
    return (unsigned char)diff;
}

PPMImage *imageDifference(AccurateImage *imageInSmall, AccurateImage *imageInLarge, PPMImage *imageOut) {
    int pixelCount = imageInSmall->x * imageInSmall->y;
    imageOut->x = imageInSmall->x;
    imageOut->y = imageInSmall->y;

    #pragma omp parallel for
    for (int i = 0; i < pixelCount; i++) {
        imageOut->data[i].red = processDifference(imageInLarge->data[i].red, imageInSmall->data[i].red);
        imageOut->data[i].green = processDifference(imageInLarge->data[i].green, imageInSmall->data[i].green);
        imageOut->data[i].blue = processDifference(imageInLarge->data[i].blue, imageInSmall->data[i].blue);
    }

    return imageOut;
}



int main(int argc, char **argv) {
    omp_set_num_threads(4);

    PPMImage *image = (argc > 1) ? readPPM("flower.ppm") : readStreamPPM(stdin);


    char *memoryBlock = malloc(276480001);
    AccurateImage *imageAccurate = (AccurateImage *)memoryBlock;

    AccuratePixel *tempHorizontal = (AccuratePixel *)memoryBlock;
    AccuratePixel *tempVertical = (AccuratePixel *)(memoryBlock + 27648000);

    int radii[] = {2, 3, 5, 8};

    char *currentBlock = memoryBlock + 55296000;
    AccurateImage *original[4], *copy[4];


    for (int i = 0; i < 4; i++) {
        original[i] = (AccurateImage *)currentBlock;
        original[i]->data = (AccuratePixel *)(currentBlock + sizeof(AccurateImage));
        currentBlock += sizeof(AccurateImage) + 27648000;

        copy[i] = (AccurateImage *)currentBlock;
        copy[i]->data = (AccuratePixel *)(currentBlock + sizeof(AccurateImage));
        currentBlock += sizeof(AccurateImage) + 27648000;
    }

    #pragma omp parallel for
    for (int i = 0; i < 4; i++) {
        convertToAccurateImage(image, original[i]);
        convertToAccurateImage(image, copy[i]);
    }

    for (int i = 0; i < 4; i++) {
        blurIteration(copy[i], original[i], radii[i], tempHorizontal, tempVertical);
        blurIteration(original[i], copy[i], radii[i], tempHorizontal, tempVertical);
        blurIteration(copy[i], original[i], radii[i], tempHorizontal, tempVertical);
        blurIteration(original[i], copy[i], radii[i], tempHorizontal, tempVertical);
        blurIteration(copy[i], original[i], radii[i], tempHorizontal, tempVertical);
    }

    PPMImage *final_images[3];
    #pragma omp parallel for

    for (int i = 0; i < 3; i++) {
        final_images[i] = (PPMImage *)(memoryBlock + i * (sizeof(PPMImage) + 6912000));
        final_images[i]->data = (PPMPixel *)((char *)final_images[i] + sizeof(PPMImage));
    }
        #pragma omp parallel for

    for (int i = 0; i < 3; i++) {
        final_images[i] = imageDifference(copy[i], copy[i+1], final_images[i]);
    }

    if (argc > 1) {
        writePPM("flower_tiny.ppm", final_images[0]);
        writePPM("flower_small.ppm", final_images[1]);
        writePPM("flower_medium.ppm", final_images[2]);
    } else {
        writeStreamPPM(stdout, final_images, 3);
    }

    free(memoryBlock);


    return 0;
}